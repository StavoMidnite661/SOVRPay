mod config;
mod memory;
mod record;
mod val;

pub use memory::Memory;
pub use record::{MemOpRecord, MemRecord};
