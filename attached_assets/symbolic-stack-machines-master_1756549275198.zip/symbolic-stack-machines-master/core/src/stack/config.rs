#[derive(Clone, Default)]
pub struct StackConfig {}
