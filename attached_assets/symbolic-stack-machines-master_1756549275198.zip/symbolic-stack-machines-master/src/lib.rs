#[cfg(feature = "core")]
pub mod core {
    pub use symbolic_stack_machines_core::*;
}

#[cfg(feature = "full")]
pub mod contrib {
    pub use symbolic_stack_machines_contrib::*;
}
