# Resources

## Postman Collections

Below is the list of postman collections.

- [Open Banking - UK_OBIE.postman_collection](/assets/postman/UK_OBIE.postman_collection)
