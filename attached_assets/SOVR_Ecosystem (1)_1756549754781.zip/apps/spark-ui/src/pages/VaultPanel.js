import React from 'react';
const VaultPanel = () => {
  return (
    <div className="card">
      <h2>🏦 Vault Controls</h2>
      <button onClick={() => alert("Deposit logic here")}>Deposit</button>
      <button onClick={() => alert("Withdraw logic here")}>Withdraw</button>
    </div>
  );
};
export default VaultPanel;
