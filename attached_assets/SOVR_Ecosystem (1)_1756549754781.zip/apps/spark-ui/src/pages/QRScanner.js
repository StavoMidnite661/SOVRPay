import React from 'react';
const QRScanner = () => {
  return (
    <div className="card">
      <h2>📷 QR Scanner</h2>
      <p>Live decode and trigger actions (Coming Soon)</p>
    </div>
  );
};
export default QRScanner;
