import React from 'react';
const AdminPanel = () => {
  return (
    <div className="card">
      <h2>🧑‍💼 Admin Panel</h2>
      <p>Track system actions, update roles (Coming Soon)</p>
    </div>
  );
};
export default AdminPanel;
