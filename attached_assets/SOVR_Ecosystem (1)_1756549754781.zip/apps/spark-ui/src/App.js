import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import AdminPanel from './pages/AdminPanel';
import VaultPanel from './pages/VaultPanel';
import QRScanner from './pages/QRScanner';

const App = () => (
  <Router>
    <div className="app-container">
      <h1>SPARK + SOVR UI</h1>
      <nav style={{ marginBottom: 20 }}>
        <Link to="/" style={{ marginRight: 10 }}>Home</Link>
        <Link to="/vault" style={{ marginRight: 10 }}>Vault</Link>
        <Link to="/qr" style={{ marginRight: 10 }}>QR Scanner</Link>
        <Link to="/admin">Admin</Link>
      </nav>
      <Routes>
        <Route path="/" element={<p>Welcome to the Unified Sovereign UI</p>} />
        <Route path="/vault" element={<VaultPanel />} />
        <Route path="/qr" element={<QRScanner />} />
        <Route path="/admin" element={<AdminPanel />} />
      </Routes>
    </div>
  </Router>
);
export default App;
