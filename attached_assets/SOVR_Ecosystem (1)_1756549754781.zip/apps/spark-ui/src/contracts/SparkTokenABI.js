export const SparkTokenABI = [
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "account",
        "type": "address"
      }
    ],
    "name": "balanceOf",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
];
export const SPARK_CONTRACT_ADDRESS = '0x6ad4e07dfba279ca5b4dece9edc3028aec65be56';