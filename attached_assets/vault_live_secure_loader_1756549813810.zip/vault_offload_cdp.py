
import json
import os
from datetime import datetime
from dotenv import load_dotenv
from coinbase_client import send_usdc_payout

# Load .env
load_dotenv()

# Load payload
try:
    with open("trigger_payload.json", "r") as f:
        payload = json.load(f)
except FileNotFoundError:
    print("❌ trigger_payload.json not found.")
    exit(1)

print("📩 Payload loaded:")
print(json.dumps(payload, indent=2))

amount = payload.get("amount", 0)
memo = payload.get("memo", "No memo")
recipient = os.getenv("CDP_RECIPIENT")

# Load secret from PEM file securely
pem_path = os.getenv("CDP_API_KEY_SECRET_FILE")
if pem_path and os.path.exists(pem_path):
    with open(pem_path, "r") as pem_file:
        api_key_secret = pem_file.read()
else:
    print("❌ PEM file not found or CDP_API_KEY_SECRET_FILE not set.")
    exit(1)

print("🚀 Sending USDC payout...")
result = send_usdc_payout(amount, recipient, api_key_secret)

# Log result
entry = {
    "timestamp": datetime.utcnow().isoformat(),
    "amount": amount,
    "memo": memo,
    "recipient": recipient,
    "result": result
}
with open("offload_ledger.json", "a") as ledger:
    ledger.write(json.dumps(entry) + "\n")

print("✅ Offload complete:", result)
