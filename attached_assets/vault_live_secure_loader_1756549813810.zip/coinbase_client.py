
import os
from dotenv import load_dotenv
from cdp import Cdp

load_dotenv()

def send_usdc_payout(amount, recipient, api_key_secret):
    try:
        cdp = Cdp(
            api_key_id=os.getenv("CDP_API_KEY_ID"),
            api_key_secret=api_key_secret,
            wallet_secret=os.getenv("CDP_WALLET_SECRET"),
            organization_id=os.getenv("CDP_ORG_ID")
        )

        response = cdp.wallet.send(
            asset="USDC",
            amount=amount,
            to=recipient
        )
        return {"status": "success", "tx_hash": response["id"]}
    except Exception as e:
        return {"status": "error", "message": str(e)}
